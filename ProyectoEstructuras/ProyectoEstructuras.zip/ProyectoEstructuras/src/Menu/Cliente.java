package Menu;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Cliente {
    private List<Cliente> vuelos = new ArrayList<>();
    private Stack<Integer> millas= new Stack<>();
    private String nombre;
    private int tiquetes;

    public Cliente() {
    }

    public Cliente(List<Cliente> vuelos, Stack<Integer> millas, String nombre, int tiquetes) {
        this.vuelos = vuelos;
        this.millas = millas;
        this.nombre = nombre;
        this.tiquetes = tiquetes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTiquetes() {
        return tiquetes;
    }

    public void setTiquetes(int tiquetes) {
        this.tiquetes = tiquetes;
    }

    public List<Cliente> getVuelos() {
        return vuelos;
    }

    public Stack<Integer> getMillas() {
        return millas;
    }

    public void setMillas(Stack<Integer> millas) {
        this.millas = millas;
    }

    public void setVuelos(List<Cliente> vuelos) {
        this.vuelos = vuelos;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "vuelos=" + vuelos +
                ", millas =" + millas +
                ", nombre='" + nombre + '\'' +
                ", tiquetes='" + tiquetes + '\'' +
                '}';
    }


}

