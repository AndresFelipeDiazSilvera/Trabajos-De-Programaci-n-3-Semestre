package Model;



//AUTHOR: Andres Felipe Diaz Silvera
//DATE: 03/02/2021
//DESCRIPTION: Presentando el Juego de Destiny

public abstract class Destiny{
    private String namejuego;
    private int capacidad;
    private String plataforma;
    private String dlc;
    private int edad;
    private String categoriaJuego;
    private String precio;

    public Destiny(){


    }

    public Destiny(String namejuego, int capacidad, String plataforma, String dlc, int edad, String categoriaJuego, String precio) {
        this.namejuego = namejuego;
        this.capacidad = capacidad;
        this.plataforma = plataforma;
        this.dlc = dlc;
        this.edad = edad;
        this.categoriaJuego = categoriaJuego;
        this.precio = precio;
    }

    public String getnamejuego() {
        return namejuego;
    }

    public void setnamejuego(String namejuego) {
        this.namejuego = namejuego;
    }

    public int getcapacidad() {
        return capacidad;
    }

    public void setcapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getplataforma() {
        return plataforma;
    }

    public void setplataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public String getdlc() {
        return dlc;
    }

    public void setdlc(String dlc) {
        this.dlc = dlc;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCategoriaJuego() {
        return categoriaJuego;
    }

    public void setCategoriaJuego(String categoriaJuego) {
        this.categoriaJuego = categoriaJuego;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Destiny{" +
                "namejuego='" + namejuego + '\'' +
                ", capacidad=" + capacidad +
                ", plataforma='" + plataforma + '\'' +
                ", dlc='" + dlc + '\'' +
                ", edad=" + edad +
                ", categoriaJuego='" + categoriaJuego + '\'' +
                ", precio='" + precio + '\'' +
                '}';
    }
    @Override
    public int hashCode() {
        return capacidad;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Destiny other = (Destiny) obj;
        if (this.capacidad != other.capacidad) {
            return false;
        }
        return true;
    }
}