package Model;

public class Estudiante {
}
