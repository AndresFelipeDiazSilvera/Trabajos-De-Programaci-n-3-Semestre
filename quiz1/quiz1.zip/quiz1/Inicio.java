/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz1;

import controller.Panaderia;
import model.Cliente;

/**
 *
 * @author yolima
 */
public class Inicio {

   private Panaderia tienda;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // añadir panes
        // vender pan: registrar cada cliente que va llegando y decirle el total
        
        //corregir errores (sintaxis y de lógica)
        
        //agregar try/catch correcta y realizar la guía de error para que no se dañe el programa
        
        
    }
    
}
